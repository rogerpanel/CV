# R6 anchors report (2026-10-18)

## Access failure (read first)
WebFetch returned `getaddrinfo ENOTFOUND` for every host tried (smj.org.sa, medrxiv.org, pmc/www.ncbi, pubmed,
ebi.ac.uk/europepmc, europepmc.org, mdpi.com, wikipedia); shell curl to all these hosts is blocked by the proxy.
Only WebSearch worked. **No paper or table was opened.** Every number here is from search-engine snippets
("search-snippet" access) and must be re-verified against the tables before use as a raking anchor.

## Task A - Kussaibi 2021 (Saudi Med J 42(3):293-298, DOI 10.15537/smj.2021.42.3.20200711, PMC7989269)
| item | caller's value | what was seen | status |
|---|---|---|---|
| n Saudi | 286 (of 482; 196 non-Saudi) | abstract: 482 total, 286 Saudi (60%) | confirmed (abstract) |
| years | 1998-2017 | abstract 1998-2017 | confirmed |
| grade 1/2/3 | 25/156/105 (8.7/54.5/36.7) | Table 1 has grade by nationality, cells not seen. medRxiv preprint: 8.2/54.6/37.1% | **UNCONFIRMED; preprint differs** |
| ER+ | 161/281 = 57.3% | Table 2 snippet: ER+ 57.3% (161); abstract ER-neg 42.7% | % and count consistent; denominator 281 not seen |
| PR+ | 126/280 = 45.0% | Table 2: 45.0% (126); abstract PR-neg 55.0% | consistent; denominator not seen |
| HER2+ | 69/273 = 25.3% | Table 2: 25.3% (69); abstract HER2-neg 74.7% | consistent; denominator not seen |
| histology | IDC 91.3 / ILC 7.0 / other 1.7 | preprint: IDC-NOS 88.7, ILC 6.9 | **UNCONFIRMED; preprint differs** |
| median age | 51 | not seen | unconfirmed |

Note the preprint is a different data cut (498 patients, 1998-2018, 291 Saudi (58.4%)); preprint receptor negativity
42.5/54.6/74.5% vs published 42.7/55.0/74.7%. So preprint figures cannot validate the published ones. Grade 25/156/105 sums to
286 (i.e., implies no missing grade) - worth checking, since ER/PR/HER2 have missing values.

## Task B - candidate studies (all search-snippet)
| study | setting | n | grade 1/2/3 % | ER/PR/HER2 + % | notes |
|---|---|---|---|---|---|
| Durrani 2025 Healthcare | KFMC Riyadh, 2013/16-2019 | 294 | 4.1/45.3/46.9 (12/133/138) | 63.4/54.3/34.9 | 40% stage IV - referral-heavy; IDC 83.9%; mean age 51.6; <=50 133/294 |
| Albasri 2014 Saudi Med J | KFH Al-Madinah, 2006-13 | 339 | G3 48.7% (165) only | n/a | IDC 85.2% |
| Alamri 2024 Cureus | Najran, 2018-22 | 61 | 29.5/41.0/29.5 (18/25/18) | ER ?/PR 54.1/HER2 34.4 | too small |
| Tawam 2020 (gene+ only) | Al Ain UAE, 2016-18 | 130 | 9.2/43.0/47.7 | subtype counts | selected germline-positive; not an anchor |
| Kuwait ~2007 | national | ? | 10.2/50.6/39.2 | snippet incoherent | pre-2010, may include DCIS |
| Oman 2014 | Royal Hospital, 2006-10 | 542 | only within-subtype | - | grade x subtype partial |

High-value full texts to open next (grade almost certainly tabulated): Elkum 2025 JEGH (KFSH&RC, n=1035 Saudi women),
Aamir 2026 SJMMS (KAMC Riyadh, n=300 Saudi), Almohanna 2025 Sci Rep (KFSH-Dammam, n=5954; ER+61, PR+56, HER2+19%),
Omer 2024 Saudi Med J (Riyadh), Alnegheimish 2016 Saudi Med J (KKUH), Al Tamimi 2010 BMC Cancer (n=231), Bahrain PMID 32342914 (n=216).
Cross-tabs: none seen; Oman 2014 and Elkum 2025 report grade x subtype associations (subtype = ER/PR x HER2), Durrani reports grade x Ki67.

## Task C - registry
- Saudi Cancer Registry, Cancer Incidence Report 2022 (latest found): female breast cancer 3,280 cases; 31.3% of all female
  cancers (17.3% of all cancers in Saudi nationals); ASR 49.7/100,000 Saudi females; median age at diagnosis 52 (range 18-106).
  https://shc.gov.sa/Arabic/NewNCC/Activities/AnnualReports/Cancer%20Incidence%20Report%202022.pdf  (snippet; PDF not opened).
  Caution: 2020 SCR reportedly ASR 28.4 (2,459 cases, 31.4%) - jump to 49.7 should be checked (possible change of standard population / denominator).
- GLOBOCAN 2022 Saudi Arabia (secondary sources citing it): ~3,777-3,800 new female breast cases, ASR ~25.3/100,000,
  13.4% of all cancers, 1,046 deaths; fact sheet https://gco.iarc.who.int/media/globocan/factsheets/populations/682-saudi-arabia-fact-sheet.pdf (not opened).
