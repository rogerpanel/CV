# bc-grade-opendata

**Predicting Nottingham histological grade of breast cancer from routine clinicopathological variables:
a leakage-audited, multi-cohort open-data study with transport to Saudi case-mix.**

Reproducibility package for the manuscript in [`paper/main.tex`](paper/main.tex) (v1.0 submission build).
It replaces two earlier single-centre manuscripts on a restricted Saudi MOH extract with an analysis that
anyone can re-run from public data: **no ethics approval, data-use agreement or account is needed**.

## Reproduce everything

```bash
pip install -r requirements.txt        # Python 3.11+ (v0.1 run: 3.13)
make all                               # data → tests → experiments E1–E8 → tables/figures → PDF
```

`make all` takes ≈ 1.5–2 hours on four CPU cores at the submission settings (10 repeats, 2000 bootstraps,
m = 20 imputations); set `cv.repeats: 2` and `bootstrap: 200` in `configs/experiment.yaml` for a 15-minute check. Every number in the PDF comes from
`paper/generated/numbers.tex`, written by `experiments/report.py` from `results/`. Reviewers can check any
claim by running one stage, e.g. `python experiments/run.py e4` (leakage audit).

## Data (downloaded, never redistributed)

| Cohort | Source | Country | Role | Graded n |
|---|---|---|---|---|
| METABRIC | cBioPortal `brca_metabric` | UK / Canada | development | 2386 |
| MSK-2018 | cBioPortal `breast_msk_2018` | USA | external (full features) | 1573 |
| MBCproject | cBioPortal `brca_mbcproject_2022` | USA / Canada | external (core) | 207 |
| Sanger | cBioPortal `brca_sanger` | UK / Europe | external (core) + leakage demo | 100 |
| Broad | cBioPortal `brca_broad` | Mexico, Vietnam | external (core) | 59 |
| BCCRC | cBioPortal `brca_bccrc` | Canada (TNBC) | descriptive | 63 |
| Duke-Breast-Cancer-MRI | TCIA (checksummed GitHub mirror of the clinical + imaging-feature XLSX) | USA | external (full) + radiomics arm | 637 |
| TCGA-BRCA | cBioPortal PanCancer Atlas | USA | descriptive (no grade) | – |
| Ljubljana | UCI id 14 (GitHub mirror) | Slovenia | sensitivity | 286 |

`scripts/download_tabular.py` fetches the files and writes SHA-256 checksums to `data/raw/MANIFEST.json`.
Saudi context enters through published aggregate figures in `configs/anchors.yaml`. The Saudi/Egyptian
Duke MRI clinical data and 529 DCE-MRI radiomic features are used in E3/E9 (CC BY-NC 4.0: non-commercial use).
The image-level arm (KAU-BCMD, CDD-CESM, BUSI) is prepared in `scripts/download_imaging.py` (RUNBOOK R8–R9) but
not run: Kaggle/TCIA image hosts were not reachable from the build environment.

## What the experiments do

| Stage | Question | Key output |
|---|---|---|
| E1 | Cohort profiles; associations with Kendall τb / Cramér's V / Spearman ρ, bootstrap CIs, BH-FDR | `tab_cohorts`, `tab_associations` |
| E2 | Nested 10×5 CV model ladder in METABRIC (majority → LR → ordinal LR → kNN → RF → XGBoost → LightGBM; TabPFN if weights available); paired Δ vs LR | `tab_internal` |
| E2mi | Multiple imputation (m = 20, pooled predictions) and complete-case sensitivity | `tab_mi` |
| E3 | External validation without refitting (MSK-2018, Duke full; + MBCproject, Sanger, Broad core); LODO | `tab_external`, `tab_lodo` |
| E4 | Leakage audit: NPI, SMOTE before split, grade components, record-level split | `tab_leakage` |
| E5 | Calibration, intercept update, decision curves | `fig_calibration_dca` |
| E6 | SHAP direction tests vs pre-specified expectations; ordinal odds ratios | `tab_shap` |
| E7 | Raking to published Saudi case-mix (all anchors, bootstrap CIs, pooled anchor, age sensitivity) | `tab_transport`, `tab_agesens` |
| E8 | Ljubljana sensitivity | `tab_ljubljana` |
| E9 | Duke: clinical vs DCE-MRI radiomics vs fusion (nested CV) | `tab_duke_radiomics` |
| E10 | Riley/Pate multinomial sample size | `tab_samplesize`, `results/sample_size.json` |

Figures are native pgfplots (`paper/figures/*_pgf.tex`) drawing from `paper/generated/data/*.csv`;
Figure 1 (framework) is TikZ. Matplotlib PDFs of the same data are also written to `paper/generated/`.

## Safeguards (see `tests/`)
In-situ disease is excluded, never relabelled; ILC is never merged with IDC; one row per patient; every
learned step (imputation, scaling, resampling) is fitted inside training folds only; grade-encoding
columns (NPI, Nottingham component scores) are never predictors.

## For Claude Code
Read `CLAUDE.md` (working rules) and `RUNBOOK.md` (step-by-step plan from v0.1 to submission).

## Licence and citation
Code: MIT (`LICENSE`). Data remain under their custodians' terms. Cite via `CITATION.cff`.
