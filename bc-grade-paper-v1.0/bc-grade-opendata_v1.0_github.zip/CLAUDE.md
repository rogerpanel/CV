# CLAUDE.md — working rules for Claude Code in this repository

This repo is the reproducibility package for the manuscript in `paper/main.tex`
(open-data breast cancer histological-grade prediction; merged MOH Manuscripts 2 + 3).
Start every session by reading `RUNBOOK.md` and the "Status" table at its top.

## Non-negotiable rules
1. **No number is typed by hand into the paper.** Every figure, table and in-text number comes from
   `results/` → `experiments/report.py` → `paper/generated/` (`numbers.tex` macros, `tab_*.tex`, `fig_*.pdf`).
   If you change an analysis, re-run `make experiments report paper` and read the diff of `numbers.tex`.
2. **Every learned step stays inside the sklearn/imblearn Pipeline** (array copy → imputation → scaling →
   optional SMOTE → model). Never fit an imputer, scaler, resampler or feature selector on data that
   includes a test fold. `tests/test_pipeline.py` guards this; add a test when you add a step.
3. **Leakage columns are never predictors** of grade: NPI (contains grade), Nottingham component scores
   (tubule/pleomorphism/mitotic), stage (contains T/N but also used for selection), PAM50/IntClust/Oncotype
   unless explicitly in a sensitivity analysis. Keep `test_leakage_columns_never_in_feature_sets` passing.
4. **In-situ disease is excluded, never relabelled.** ILC is never merged with IDC. Grade is invasive
   Nottingham/differentiation grade 1–3 only.
5. **One row per patient.** Any image or multi-sample source must be split with patient-grouped CV
   (`StratifiedGroupKFold`).
6. **Data are not redistributed.** `data/` is git-ignored. Download scripts + `data/raw/MANIFEST.json`
   (SHA-256) are the provenance record. Respect CC BY-NC terms (Duke MRI, BRACS). Never use a source that
   needs a signed DUA (VinDr-Mammo, full EMBED) without the PI's written decision.
7. **Seeds**: `configs/experiment.yaml: seed`. Do not change the seed to improve a result.
8. Commit messages: imperative, one logical change each; never commit `data/` or large `results/*.npz`.

## Layout
```
configs/      datasets.yaml (sources, licences, roles) · experiment.yaml (CV, seeds, raking targets) · anchors.yaml (Saudi published figures)
scripts/      download_tabular.py (open cBioPortal + UCI mirror) · download_imaging.py (arm B, Kaggle/TCIA)
src/bcgrade/  harmonise.py (common data model) · describe.py (scale-appropriate stats) · models.py (ladder) · evaluate.py (metrics, CI, calibration, DCA, raking)
experiments/  run.py (E1–E8) · report.py (tables/figures/macros)
tests/        pytest guards for harmonisation and leakage
paper/        main.tex · refs.bib · generated/ (never edit by hand)
```

## Common commands
```
make data          # download + checksum
make test          # guards
make experiments   # E1–E8 (~15–25 min on 2 CPU cores at repeats=5)
make report paper  # regenerate tables/figures/macros and compile the PDF
python experiments/run.py e3 e5   # re-run selected stages (E5 and E7 depend on E2 + E3 outputs)
```
