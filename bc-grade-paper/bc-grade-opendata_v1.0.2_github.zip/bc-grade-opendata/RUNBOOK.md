# RUNBOOK — taking v0.1 to a submission-ready paper with Claude Code

This runbook is written for a Claude Code session (or a human analyst) working on a branch of this
repository. Each step has an **action**, the **files it touches** and an **acceptance check**. Work top
to bottom; tick the status table as you go and commit after each step.

```
git checkout -b submission-run
claude                      # then: "Read CLAUDE.md and RUNBOOK.md, then do step R1"
```

## Status at v1.0 (2026-10-18, submission build)

| Area | State |
|---|---|
| R1 data + guards | Done — checksums unchanged since v0.1; 12 tests pass (2 new: MI pooling, Duke in-situ/components) |
| R2 exact reproduction of v0.1 | Done — `numbers.tex` identical after a clean re-download and re-run |
| R3 submission resampling (10 repeats, 2000 bootstraps) | Done |
| R4 multiple imputation (m = 20, pooled predictions) + complete case | Done — `e2mi`, `tab_mi` |
| R5 TabPFN | **Blocked** — weights gated on Hugging Face (login + licence) and huggingface.co unreachable from the build sandbox; code path in `make_model("tabpfn")`, runs automatically when weights are cached (`optional_models_status.json`) |
| R6 more Saudi/Gulf anchors | Partly done — Riyadh (Durrani 2025), Najran, Madinah added; pooled random-effects anchor; age-share sensitivity; bootstrap CIs. **All new values are abstract/snippet-level** (journal sites unreachable) → V2 must re-read the tables |
| R7 sample size (Riley/Pate multinomial) | Done — `e10`; criteria **not met** for the G1-vs-G2 sub-model (reported in the paper) |
| R8–R9 image-level arm (KAU-BCMD, CDD-CESM, BUSI) | **Blocked** — Kaggle/TCIA hosts unreachable from the build sandbox |
| R10 Duke-Breast-Cancer-MRI | Done — clinical + 529 radiomics from a checksummed GitHub mirror of the TCIA XLSX; Duke is a second full-feature external cohort, in LODO, leakage audit (component scores) and E9 radiomics fusion |
| R11 manuscript | Done — rebuilt: Figure 1 framework (TikZ), pgfplots charts from `generated/data/*.csv`, new Introduction/Discussion, abstract |
| V1 citations | Done via search-engine records (79 entries; `paper/refs_annotated.bib` keeps provenance notes). One DOI-resolver pass from an unrestricted machine still advised |
| V2 anchor double-read | **To do (human)** |
| V3 TRIPOD+AI full checklist | Done (Supplementary Table) — STROBE checklist still to add |
| V4 independent clean re-run | To do on a second machine |
| G1 GitHub + Zenodo | Package ready (`.github/workflows/ci.yml` added); repository creation + DOI = PI |
| Author list, affiliations, funding, CRediT, PPI statement | To do PI |

Headline v1.0 results (from `paper/generated/numbers.tex`): internal macro-AUC 0.72–0.73 for every learned
model, XGBoost − LR = +0.001 (95% CI −0.006 to +0.008); external full-feature macro-AUC 0.69–0.71 (MSK-2018),
0.70–0.72 (Duke); grade-3 calibration slope ≈ 1 externally but intercept +0.99 (MSK) and −1.02 (Duke), both fixed
by intercept update; MI vs single imputation Δ ≤ 0.003; leakage inflation up to +0.30; Duke radiomics fusion
−0.045 vs clinical; Riley sample size not met (4477 required vs 2386); Saudi case-mix raises each cohort's
grade-3 share by ≈ +10 points, and a METABRIC model would predict 59% grade 3 vs 36.7% published (Dammam).

Headline v0.1 results (superseded; see `paper/generated/numbers.tex` for v1.0) (all from `paper/generated/numbers.tex`): internal macro-AUC ≈ 0.72 for every
learned model (logistic regression = XGBoost); external macro-AUC 0.64–0.80; grade-3 calibration slope ≈ 1.03
in MSK-2018 but intercept ≈ +0.99 (baseline-risk shift, fixed by intercept update); 7/7 SHAP directions
plausible; leakage inflates macro-AUC by up to +0.27; Saudi re-weighting implies ≈ 61% grade 3 vs 36.7%
published → Western models would over-predict grade 3 in Saudi patients.

---

## R0 — Environment (15 min)
**Action.** `python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt`.
LaTeX: TeX Live with `charter`, `natbib`, `booktabs`, `enumitem`, `hyperref`, `latexmk`.
**Accept.** `python -c "import sklearn, xgboost, lightgbm, shap, statsmodels, imblearn"` succeeds.

## R1 — Data + guards (5 min)
**Action.** `make data test`.
**Accept.** 10 tests pass. `git diff data/raw/MANIFEST.json` is empty; if checksums changed, cBioPortal
updated a study — record the date in `paper/main.tex` Data availability and re-run everything.

## R2 — Reproduce v0.1 exactly (≈ 15 min, 2 cores)
**Action.** `make experiments report paper`.
**Accept.** `git diff paper/generated/numbers.tex` shows no change (the seed is fixed). If numbers move by
more than ±0.002, compare package versions with `results/run_*.json` before continuing.

## R3 — Submission-grade resampling
**Action.** In `configs/experiment.yaml` set `cv.repeats: 10`, `bootstrap: 2000`. Run `make experiments report paper`.
**Accept.** Methods text updates automatically through `\Repeats` / `\Boot`. Macro-AUCs change < 0.005.

## R4 — Multiple imputation with pooled predictions
**Why.** Reviewers will ask; v0.1 uses single in-fold chained-equation imputation.
**Action.** In `src/bcgrade/models.py` add `MIClassifier(m=20)`: inside `fit`, create m
`IterativeImputer(sample_posterior=True, random_state=seed+i)` → scaler → clone(model) pipelines; in
`predict_proba`, average the m probability matrices. Register as model option `mi=True`; add a test that
predictions are averaged over m distinct imputations. Add an experiment `e2mi` for `mlr` and `xgb` only.
Add a complete-case sensitivity row. Report in a new supplementary table `tab_mi.tex`.
**Accept.** MI and single-imputation macro-AUC differ by < 0.01, or the paper discusses why not.

## R5 — Tabular foundation model (TabPFN)
**Action.** `pip install tabpfn` (needs model weights from Hugging Face on first use). Add `"tabpfn"` to
`make_model` (no tuning grid; `TabPFNClassifier(random_state=seed)`), include in E2/E3/LODO.
Cite `hollmann2025tabpfn` (already in refs.bib).
**Accept.** Runs within the CV harness without leakage (it sits after impute/scale in the Pipeline).
Expectation from v0.1: it will not beat regression by more than the CI; report either way.

## R6 — Strengthen the Saudi / Gulf anchor (key for sponsors)
**Action.**
1. Find further published Saudi/Gulf clinicopathological series reporting grade, ER/PR/HER2, histology
   and age (Saudi Medical Journal, Annals of Saudi Medicine, J Clin Med, Cureus, BMC Cancer; KFSH&RC
   Riyadh, KAMC Riyadh/Jeddah, KAUH Jeddah; also UAE, Kuwait, Oman, Qatar).
   Transcribe Table 1 counts into `configs/anchors.yaml` (one block per study, with page and table numbers).
2. Generalise `e7` to loop over all anchors and add a random-effects pooled Saudi grade distribution.
3. Add a "joint" sensitivity: rake on ER × HER2 jointly if any study reports the cross-tab.
4. Add Saudi Cancer Registry figures used in the Introduction (Basudan 2022 already; add the most recent SCR report).
**Accept.** Every anchor value has a citation + table/page reference in a YAML comment and is
double-checked by a second reader (V2).

## R7 — Sample-size justification
**Action.** Use `pmsampsize` (R) or a Python port for a multinomial outcome (Riley et al. BMJ 2020; Pate et al.
for multinomial). Inputs: 10 parameters, smallest class prevalence 0.089, anticipated Cox–Snell R² from
v0.1 (compute from METABRIC logistic model). Write the output into `results/sample_size.json` and a sentence
in Methods via a macro.
**Accept.** Required n ≤ 2386, or the paper says it is not met.

## R8 — Imaging arm B1: KAU-BCMD (Saudi mammography)
**Action.**
1. `pip install kaggle`; place `~/.kaggle/kaggle.json`; `python scripts/download_imaging.py kau_bcmd`.
2. Build `src/bcgrade/imaging/kau.py`: index images → patient/case id → BI-RADS label; record the version
   (the Kaggle folders hold BI-RADS 1, 3, 4, 5; the paper describes 1–5 — document what you downloaded).
3. Task: BI-RADS 1 vs 3 vs 4–5 (or benign-appearing vs suspicious), **StratifiedGroupKFold by case**.
4. Models: frozen ImageNet ViT/ConvNeXt or a mammography foundation model → embeddings → logistic
   regression; then fine-tuned EfficientNet-B0 on a GPU. Same metrics/calibration code.
5. Leakage demo: image-level vs case-level split (report like E4-d).
**Accept.** No case appears in two folds (unit test). Results in a new section "Imaging arm".

## R9 — Imaging arm B2: CDD-CESM (Egypt) and BUSI (Egypt)
**Action.** `python scripts/download_imaging.py cdd_cesm --manifest-only`, then full download; BUSI via Kaggle.
Tasks: pathology benign vs malignant (CDD-CESM, BUSI) and BI-RADS (CDD-CESM). Cross-site check:
train on CDD-CESM low-energy images, test on KAU-BCMD for a "suspicious vs not" label mapping
(document the mapping table in `configs/`).
**Accept.** Patient-grouped CV; external cross-site AUC reported with CI.

## R10 — Duke-Breast-Cancer-MRI clinical + radiomics (restores BI-RADS-era variables)
**Why.** It is the only open cohort linking Nottingham grade to mammographic calcification, density and
MRI radiomics (922 patients; CC BY-NC 4.0).
**Action.** Download the clinical XLSX and the 529-feature radiomics XLSX from TCIA (no image download
needed). Add `duke()` to `harmonise.py` (map Nottingham grade; drop tubule/nuclear/mitotic scores —
leakage; code calcification and density). Add Duke as (a) external validation cohort for the full CDM model,
(b) a clinical + radiomics fusion model (E9), compared with the published radiomics benchmark (validation
AUC 0.722 for grade 3 vs 1–2; cite after V1 verification).
**Accept.** New external row for Duke; licence note (non-commercial) added to Data availability.

## R11 — Manuscript update
**Action.** Re-run `make report paper`. Rewrite only prose; never hard-code a number (CLAUDE.md rule 1).
Update the abstract (≤ 300 words for most journals) and the TRIPOD+AI table.
**Accept.** `grep -nE "[0-9]\.[0-9]{2,}" paper/main.tex paper/sections/*.tex` shows only published
anchor figures (Saudi/registry) and software versions, no results.

## V1 — Citation verification
Check every `refs.bib` entry with a DOI resolver; fix all `VERIFY` notes (wang2022duke, kim2025grade,
kussaibi2021saudi DOI, mbcproject2022). Remove uncited entries.

## V2 — Anchor verification
Second reader re-transcribes `configs/anchors.yaml` from the source PDFs blind, then diff.

## V3 — Reporting checklists
Complete the full TRIPOD+AI (27 items) and STROBE checklists as supplementary PDFs; replace the
abbreviated Table S5.

## V4 — Independent re-run
On a clean machine: `git clone … && make all`; `numbers.tex` must match the committed version.

## G1 — GitHub + Zenodo release
1. Create the GitHub repository (public), push `main` (data and `results/*.npz` are git-ignored).
2. Enable the Zenodo–GitHub integration, tag `v1.0.0`, cite the DOI in `paper/main.tex` and `CITATION.cff`.
3. Add a GitHub Action running `make data test` on push (CPU, < 5 min).

---

### Journal targeting note
Q1 options that publish open-data prediction studies with TRIPOD+AI: *Breast Cancer Research and
Treatment*, *The Breast*, *JCO Clinical Cancer Informatics*, *npj Breast Cancer* (needs imaging/genomic
angle — R8–R10), *Diagnostic and Prognostic Research* (methods angle: the leakage audit). Decide after R10.
