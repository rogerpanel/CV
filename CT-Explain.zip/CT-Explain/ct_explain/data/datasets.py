"""Dataset loaders for the six benchmarks used in the manuscript.

Paper: "84.2M labeled samples, 6 benchmarks" — CIC-IoT-2023,
CSE-CICIDS2018, UNSW-NB15, MS GUIDE, Container-NID, Edge-IIoT. They are
distributed as two Kaggle bundles referenced by DOI:

    General network traffic (3 sets): doi.org/10.34740/kaggle/dsv/12483891
    Cloud / microservices / edge (3 sets): doi.org/10.34740/KAGGLE/DSV/12479689

These loaders are CSV-first: point ``root`` at the directory where the
Kaggle bundle was unpacked and the constructor walks it for the expected
dataset subfolders. For unit-testing and dry-runs each loader also accepts
a synthetic mode (``synthetic=True``) that generates a small compliant
frame without needing the real data.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator, Optional, Sequence

import numpy as np
import pandas as pd

from ct_explain.data.graph_builder import (
    ContinuousTimeGraphBuilder,
    TemporalGraph,
)
from ct_explain.data.preprocessor import NetFlowPreprocessor
from ct_explain.utils.logging import get_logger

log = get_logger(__name__)


# ---------------------------------------------------------------------- #
# Manifest of the six benchmark datasets.
# ---------------------------------------------------------------------- #

@dataclass(frozen=True)
class DatasetManifest:
    key: str
    display_name: str
    year: int
    bundle: str                 # "general" | "cloud-edge"
    expected_rows: int
    num_attack_classes: int
    kaggle_doi: str
    description: str


MANIFEST: dict[str, DatasetManifest] = {
    "cic-iot-2023": DatasetManifest(
        key="cic-iot-2023",
        display_name="CIC-IoT-2023",
        year=2023,
        bundle="general",
        expected_rows=46_600_000,
        num_attack_classes=33,
        kaggle_doi="10.34740/kaggle/dsv/12483891",
        description="UNB CIC IoT intrusion benchmark — 33 attack classes.",
    ),
    "cse-cicids-2018": DatasetManifest(
        key="cse-cicids-2018",
        display_name="CSE-CICIDS2018",
        year=2018,
        bundle="general",
        expected_rows=16_200_000,
        num_attack_classes=14,
        kaggle_doi="10.34740/kaggle/dsv/12483891",
        description="Enterprise network flows with 14 attack classes.",
    ),
    "unsw-nb15": DatasetManifest(
        key="unsw-nb15",
        display_name="UNSW-NB15",
        year=2015,
        bundle="general",
        expected_rows=2_500_000,
        num_attack_classes=9,
        kaggle_doi="10.34740/kaggle/dsv/12483891",
        description="UNSW hybrid benchmark — 9 attack families.",
    ),
    "ms-guide-2024": DatasetManifest(
        key="ms-guide-2024",
        display_name="MS GUIDE",
        year=2024,
        bundle="cloud-edge",
        expected_rows=13_000_000,
        num_attack_classes=15,
        kaggle_doi="10.34740/KAGGLE/DSV/12479689",
        description="Microsoft Guided Incident Dataset Enhanced (API + agent logs).",
    ),
    "container-nid": DatasetManifest(
        key="container-nid",
        display_name="Container-NID",
        year=2023,
        bundle="cloud-edge",
        expected_rows=4_800_000,
        num_attack_classes=8,
        kaggle_doi="10.34740/KAGGLE/DSV/12479689",
        description="Container / Kubernetes NID dataset (cloud-native telemetry).",
    ),
    "edge-iiot": DatasetManifest(
        key="edge-iiot",
        display_name="Edge-IIoT",
        year=2022,
        bundle="cloud-edge",
        expected_rows=1_100_000,
        num_attack_classes=5,
        kaggle_doi="10.34740/KAGGLE/DSV/12479689",
        description="Industrial IIoT edge dataset covering OT protocols.",
    ),
}


def list_datasets() -> list[str]:
    return list(MANIFEST.keys())


# ---------------------------------------------------------------------- #
# Base class
# ---------------------------------------------------------------------- #

class _BaseNetflowDataset:
    """Common behaviour for the benchmark loaders."""

    manifest_bundle: str = ""
    children: Sequence[str] = ()
    _synthetic_feature_cols: Sequence[str] = (
        "flow_duration", "total_fwd_pkts", "total_bwd_pkts",
        "total_fwd_bytes", "total_bwd_bytes", "flow_pkts_s", "flow_bytes_s",
        "pkt_len_mean", "pkt_len_std", "iat_mean", "iat_std",
        "syn_flag_cnt", "ack_flag_cnt", "fin_flag_cnt", "rst_flag_cnt",
        "bytes_per_pkt", "pkts_per_second",
    )

    def __init__(
        self,
        root: Optional[str] = None,
        include: Optional[Sequence[str]] = None,
        synthetic: bool = False,
        synthetic_rows: int = 4096,
        chunk_size: int = 250_000,
        feature_dim: int = 83,
    ) -> None:
        self.root = Path(root) if root else None
        self.synthetic = synthetic
        self.synthetic_rows = synthetic_rows
        self.chunk_size = chunk_size
        self.feature_dim = feature_dim
        self._include = list(include) if include else list(self.children)
        self.preprocessor = NetFlowPreprocessor(feature_dim=feature_dim)
        self._fitted = False

    # -------------------------------------------------------------- #
    # Public API
    # -------------------------------------------------------------- #
    def manifests(self) -> list[DatasetManifest]:
        return [MANIFEST[k] for k in self._include]

    def load_training_frame(self) -> pd.DataFrame:
        """Read training CSVs (or synthetic substitute) into a dataframe."""
        if self.synthetic or self.root is None:
            return self._synthetic_frame(self.synthetic_rows)
        return self._read_csvs("train")

    def iter_chunks(self, split: str = "train") -> Iterator[pd.DataFrame]:
        """Chunked iterator for out-of-core training."""
        if self.synthetic or self.root is None:
            yield self._synthetic_frame(self.synthetic_rows)
            return
        for csv in self._resolve_csvs(split):
            log.info("Streaming %s", csv)
            for chunk in pd.read_csv(csv, chunksize=self.chunk_size, low_memory=False):
                yield chunk

    def build_graph(
        self,
        df: pd.DataFrame,
        max_events: Optional[int] = 200_000,
    ) -> TemporalGraph:
        """Materialize one TemporalGraph snapshot from a flow frame."""
        if max_events is not None and len(df) > max_events:
            df = df.sort_values("timestamp").head(max_events)
        if not self._fitted:
            self.preprocessor.fit(df)
            self._fitted = True
        feats = self.preprocessor.transform(df)
        labels = self._labels(df)

        builder = ContinuousTimeGraphBuilder(default_node_feature_dim=self.feature_dim)
        for i, row in enumerate(df.itertuples(index=False)):
            src = getattr(row, "src_ip", f"host_{i % 128}")
            dst = getattr(row, "dst_ip", f"svc_{i % 32}")
            ts = float(getattr(row, "timestamp", i))
            builder.add_event(
                src_id=str(src),
                tgt_id=str(dst),
                timestamp=ts,
                edge_feature=feats[i],
                src_feature=feats[i],
                tgt_feature=feats[i],
                label=int(labels[i]) if labels is not None else None,
            )
        return builder.build(metadata={
            "dataset": ",".join(m.key for m in self.manifests()),
            "bundle": self.manifest_bundle,
        })

    # -------------------------------------------------------------- #
    # Internals
    # -------------------------------------------------------------- #
    def _resolve_csvs(self, split: str) -> list[Path]:
        if self.root is None:
            return []
        found: list[Path] = []
        for child in self._include:
            d = self.root / child
            if not d.exists():
                log.warning("Expected %s under %s (Kaggle bundle layout).", child, self.root)
                continue
            found.extend(sorted(d.glob(f"*{split}*.csv")))
            if not found:
                found.extend(sorted(d.glob("*.csv")))
        return found

    def _read_csvs(self, split: str) -> pd.DataFrame:
        csvs = self._resolve_csvs(split)
        if not csvs:
            log.warning("No CSVs found for split=%s under %s — using synthetic frame.",
                        split, self.root)
            return self._synthetic_frame(self.synthetic_rows)
        frames = [pd.read_csv(c, low_memory=False) for c in csvs]
        return pd.concat(frames, ignore_index=True)

    def _synthetic_frame(self, rows: int) -> pd.DataFrame:
        rng = np.random.default_rng(0)
        df = pd.DataFrame(
            rng.normal(size=(rows, len(self._synthetic_feature_cols))).astype(np.float32),
            columns=list(self._synthetic_feature_cols),
        )
        df["src_ip"] = [f"10.0.0.{i % 255}" for i in range(rows)]
        df["dst_ip"] = [f"10.0.1.{i % 255}" for i in range(rows)]
        df["src_port"] = rng.integers(1024, 65535, size=rows)
        df["dst_port"] = rng.integers(1, 1024, size=rows)
        df["timestamp"] = np.sort(rng.uniform(0, 86400, size=rows))
        df["label"] = rng.integers(0, 2, size=rows)
        return df

    def _labels(self, df: pd.DataFrame) -> Optional[np.ndarray]:
        if "label" in df.columns:
            return df["label"].to_numpy()
        if "attack_category" in df.columns:
            return df["attack_category"].astype("category").cat.codes.to_numpy()
        return None


# ---------------------------------------------------------------------- #
# Bundle 1: General network traffic (CIC-IoT / CSE-CIC / UNSW-NB15)
# ---------------------------------------------------------------------- #

class GeneralNetworkTrafficDataset(_BaseNetflowDataset):
    """Traditional network-flow bundle.

    Kaggle DOI: 10.34740/kaggle/dsv/12483891
    """

    manifest_bundle = "general"
    children = ("cic-iot-2023", "cse-cicids-2018", "unsw-nb15")


# ---------------------------------------------------------------------- #
# Bundle 2: Cloud, microservices & edge
# ---------------------------------------------------------------------- #

class CloudEdgeDataset(_BaseNetflowDataset):
    """Cloud-native, container, and industrial-edge bundle.

    Kaggle DOI: 10.34740/KAGGLE/DSV/12479689
    """

    manifest_bundle = "cloud-edge"
    children = ("ms-guide-2024", "container-nid", "edge-iiot")


# ---------------------------------------------------------------------- #
# Single-dataset accessor
# ---------------------------------------------------------------------- #

def get_dataset(
    key: str,
    root: Optional[str] = None,
    synthetic: bool = False,
    **kwargs,
) -> _BaseNetflowDataset:
    if key not in MANIFEST:
        raise KeyError(f"Unknown dataset '{key}'. Available: {list(MANIFEST)}")
    m = MANIFEST[key]
    cls = GeneralNetworkTrafficDataset if m.bundle == "general" else CloudEdgeDataset
    return cls(root=root, include=[key], synthetic=synthetic, **kwargs)
