"""Continuous-time graph builder.

Turns a stream of network flow records into a continuously-evolving
heterogeneous graph G(t) = (V(t), E(t), X(t)) as defined in the manuscript.
Nodes are network entities (IPs, services, users) keyed by a canonical
string; edges are timestamped communication events with their feature
vectors. The builder supports both a batched mode (all events at once) and
an incremental mode (ingest records as they arrive, e.g. in a SIEM stream).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping, Optional, Sequence

import numpy as np
import torch


@dataclass
class TemporalGraph:
    """Minimal CT-DGNN graph container.

    Attributes
    ----------
    node_ids
        Canonical string identifier for each node; index == row in tensors.
    node_features
        (N, d) node descriptor matrix (float32).
    edge_index
        (2, E) LongTensor; row 0 = target v, row 1 = source u (directed).
    edge_features
        (E, d_e) per-edge feature vector e_{vu}.
    edge_times
        (E,) float tensor of event timestamps (seconds since epoch or
        relative start).
    node_labels
        Optional (N,) LongTensor for supervised classification.
    metadata
        Free-form dict used to carry dataset name, feature schema, etc.
    """

    node_ids: list[str]
    node_features: torch.Tensor
    edge_index: torch.Tensor
    edge_features: torch.Tensor
    edge_times: torch.Tensor
    node_labels: Optional[torch.Tensor] = None
    metadata: Mapping[str, object] = None

    @property
    def num_nodes(self) -> int:
        return self.node_features.size(0)

    @property
    def num_edges(self) -> int:
        return self.edge_index.size(1)

    def to(self, device: torch.device | str) -> "TemporalGraph":
        return TemporalGraph(
            node_ids=self.node_ids,
            node_features=self.node_features.to(device),
            edge_index=self.edge_index.to(device),
            edge_features=self.edge_features.to(device),
            edge_times=self.edge_times.to(device),
            node_labels=self.node_labels.to(device) if self.node_labels is not None else None,
            metadata=self.metadata,
        )

    def window(self, t_start: float, t_end: float) -> "TemporalGraph":
        """Return a view containing only edges whose timestamp lies in
        [t_start, t_end)."""
        mask = (self.edge_times >= t_start) & (self.edge_times < t_end)
        return TemporalGraph(
            node_ids=self.node_ids,
            node_features=self.node_features,
            edge_index=self.edge_index[:, mask],
            edge_features=self.edge_features[mask],
            edge_times=self.edge_times[mask],
            node_labels=self.node_labels,
            metadata=self.metadata,
        )


class ContinuousTimeGraphBuilder:
    """Stream-friendly builder producing TemporalGraph objects."""

    def __init__(
        self,
        node_feature_fn=None,
        default_node_feature_dim: int = 16,
    ) -> None:
        self._node_feature_fn = node_feature_fn
        self._default_node_feature_dim = default_node_feature_dim
        self.reset()

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #
    def reset(self) -> None:
        self._nodes: dict[str, int] = {}
        self._node_feats: list[np.ndarray] = []
        self._edge_src: list[int] = []
        self._edge_tgt: list[int] = []
        self._edge_feat: list[np.ndarray] = []
        self._edge_time: list[float] = []
        self._node_labels: dict[int, int] = {}

    # ------------------------------------------------------------------ #
    # Ingestion
    # ------------------------------------------------------------------ #
    def add_event(
        self,
        src_id: str,
        tgt_id: str,
        timestamp: float,
        edge_feature: Sequence[float],
        src_feature: Optional[Sequence[float]] = None,
        tgt_feature: Optional[Sequence[float]] = None,
        label: Optional[int] = None,
    ) -> None:
        u = self._get_or_add(src_id, src_feature)
        v = self._get_or_add(tgt_id, tgt_feature)
        self._edge_tgt.append(v)
        self._edge_src.append(u)
        self._edge_feat.append(np.asarray(edge_feature, dtype=np.float32))
        self._edge_time.append(float(timestamp))
        if label is not None:
            # Attach supervised label to the TARGET node (convention).
            self._node_labels[v] = int(label)

    def add_stream(self, records: Iterable[Mapping]) -> None:
        for r in records:
            self.add_event(
                src_id=str(r["src"]),
                tgt_id=str(r["dst"]),
                timestamp=float(r["timestamp"]),
                edge_feature=r["features"],
                src_feature=r.get("src_features"),
                tgt_feature=r.get("dst_features"),
                label=r.get("label"),
            )

    # ------------------------------------------------------------------ #
    # Materialization
    # ------------------------------------------------------------------ #
    def build(self, metadata: Optional[Mapping] = None) -> TemporalGraph:
        if not self._edge_src:
            raise ValueError("No events have been ingested.")
        node_feats = np.stack(self._node_feats, axis=0).astype(np.float32)

        labels = None
        if self._node_labels:
            labels_arr = np.full(node_feats.shape[0], fill_value=-1, dtype=np.int64)
            for idx, lab in self._node_labels.items():
                labels_arr[idx] = lab
            labels = torch.from_numpy(labels_arr)

        return TemporalGraph(
            node_ids=[n for n, _ in sorted(self._nodes.items(), key=lambda kv: kv[1])],
            node_features=torch.from_numpy(node_feats),
            edge_index=torch.tensor([self._edge_tgt, self._edge_src], dtype=torch.long),
            edge_features=torch.from_numpy(np.stack(self._edge_feat)),
            edge_times=torch.tensor(self._edge_time, dtype=torch.float32),
            node_labels=labels,
            metadata=metadata or {},
        )

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #
    def _get_or_add(self, key: str, feat: Optional[Sequence[float]]) -> int:
        if key in self._nodes:
            return self._nodes[key]
        idx = len(self._nodes)
        self._nodes[key] = idx
        if feat is None:
            if self._node_feature_fn is not None:
                feat = self._node_feature_fn(key)
            else:
                feat = np.zeros(self._default_node_feature_dim, dtype=np.float32)
        self._node_feats.append(np.asarray(feat, dtype=np.float32))
        return idx
