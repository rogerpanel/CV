"""NetFlow-v2 preprocessor.

Manuscript protocol:
  * NetFlow-v2 format
  * 83 engineered features (flow duration, packet/byte counts, TCP flags,
    inter-arrival stats, derived ratios, payload statistics)
  * Identifier features (IPs, ports, timestamps used as keys) are *excluded*
    from the learnable input vector to prevent label leakage.
  * Per-feature z-score standardisation fitted on the training distribution.
  * Chronological train/val/test split (no random shuffle across time).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional, Sequence

import numpy as np
import pandas as pd

# Columns used as identifiers (excluded from learnable features).
DEFAULT_IDENTIFIER_COLS = [
    "src_ip", "dst_ip", "src_port", "dst_port", "timestamp", "flow_id",
    "label", "attack_category", "attack",
]


@dataclass
class FitResult:
    feature_columns: list[str]
    mean: np.ndarray
    std: np.ndarray


class NetFlowPreprocessor:
    """Stateful preprocessor: fit on training CSV then transform others.

    The 83-feature target dimension matches the RobustIDPS.ai platform
    documentation. If an input frame supplies fewer engineered columns, the
    preprocessor will zero-pad to 83; if more, it will truncate to the
    intersection (and warn).
    """

    def __init__(
        self,
        feature_dim: int = 83,
        identifier_cols: Optional[Sequence[str]] = None,
        label_col: str = "label",
    ) -> None:
        self.feature_dim = feature_dim
        self.identifier_cols = list(identifier_cols or DEFAULT_IDENTIFIER_COLS)
        self.label_col = label_col
        self.fit_: Optional[FitResult] = None

    # ------------------------------------------------------------------ #
    # Fit / transform
    # ------------------------------------------------------------------ #
    def fit(self, df: pd.DataFrame) -> "NetFlowPreprocessor":
        features = self._select_features(df)
        arr = features.to_numpy(dtype=np.float32)
        arr = self._sanitize(arr)
        mean = arr.mean(axis=0)
        std = arr.std(axis=0) + 1e-8
        self.fit_ = FitResult(
            feature_columns=list(features.columns),
            mean=mean.astype(np.float32),
            std=std.astype(np.float32),
        )
        return self

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        if self.fit_ is None:
            raise RuntimeError("Call .fit(train_df) before .transform().")
        features = self._align(df)
        arr = features.to_numpy(dtype=np.float32)
        arr = self._sanitize(arr)
        arr = (arr - self.fit_.mean) / self.fit_.std
        return self._pad(arr, self.feature_dim)

    def fit_transform(self, df: pd.DataFrame) -> np.ndarray:
        self.fit(df)
        return self.transform(df)

    def labels(self, df: pd.DataFrame) -> np.ndarray:
        if self.label_col not in df.columns:
            raise KeyError(f"Missing label column '{self.label_col}'.")
        return df[self.label_col].to_numpy()

    # ------------------------------------------------------------------ #
    # Persistence
    # ------------------------------------------------------------------ #
    def save(self, path: str | Path) -> None:
        if self.fit_ is None:
            raise RuntimeError("Nothing to save — preprocessor is not fitted.")
        np.savez(
            Path(path),
            feature_columns=np.array(self.fit_.feature_columns),
            mean=self.fit_.mean,
            std=self.fit_.std,
        )

    def load(self, path: str | Path) -> "NetFlowPreprocessor":
        data = np.load(Path(path), allow_pickle=True)
        self.fit_ = FitResult(
            feature_columns=list(data["feature_columns"]),
            mean=data["mean"],
            std=data["std"],
        )
        return self

    # ------------------------------------------------------------------ #
    # Chronological split helper
    # ------------------------------------------------------------------ #
    @staticmethod
    def chronological_split(
        df: pd.DataFrame,
        time_col: str = "timestamp",
        ratios: tuple[float, float, float] = (0.7, 0.15, 0.15),
    ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        if abs(sum(ratios) - 1.0) > 1e-6:
            raise ValueError("Split ratios must sum to 1.")
        ordered = df.sort_values(time_col).reset_index(drop=True)
        n = len(ordered)
        a, b = int(ratios[0] * n), int((ratios[0] + ratios[1]) * n)
        return ordered.iloc[:a], ordered.iloc[a:b], ordered.iloc[b:]

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #
    def _select_features(self, df: pd.DataFrame) -> pd.DataFrame:
        drop = [c for c in self.identifier_cols if c in df.columns]
        numeric = df.drop(columns=drop, errors="ignore")
        numeric = numeric.select_dtypes(include=[np.number])
        return numeric

    def _align(self, df: pd.DataFrame) -> pd.DataFrame:
        """Reindex transform-time frames to the fitted feature schema."""
        assert self.fit_ is not None
        cols = self.fit_.feature_columns
        missing = [c for c in cols if c not in df.columns]
        # Fill any missing columns with zeros (benign fallback).
        for c in missing:
            df[c] = 0.0
        return df[cols]

    @staticmethod
    def _sanitize(arr: np.ndarray) -> np.ndarray:
        arr = np.nan_to_num(arr, nan=0.0, posinf=1e6, neginf=-1e6)
        return np.clip(arr, -1e6, 1e6)

    @staticmethod
    def _pad(arr: np.ndarray, dim: int) -> np.ndarray:
        n, d = arr.shape
        if d == dim:
            return arr
        if d < dim:
            out = np.zeros((n, dim), dtype=arr.dtype)
            out[:, :d] = arr
            return out
        return arr[:, :dim]
