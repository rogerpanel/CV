"""SSMGAT: Certified Selective State-Space Detection for Multi-Protocol LLM Agent Security.

Top-level package. Heavy dependencies (mamba_ssm, torch_geometric, sentence_transformers)
are NOT imported here so the package remains importable in lightweight environments.
"""
from __future__ import annotations

__version__ = "1.0.0"

__all__ = ["__version__", "SSMGAT"]


def __getattr__(name: str):  # pragma: no cover - thin lazy import shim
    """Lazy attribute access for the top-level model name.

    Importing ``apdet.SSMGAT`` will trigger the (potentially heavy)
    ``apdet.models`` import only on demand.
    """
    if name == "SSMGAT":
        from .models import SSMGAT as _SSMGAT  # type: ignore[attr-defined]

        return _SSMGAT
    raise AttributeError(f"module 'apdet' has no attribute {name!r}")
