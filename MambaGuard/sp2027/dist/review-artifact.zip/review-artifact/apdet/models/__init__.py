"""SSMGAT model components — top-level model plus building blocks."""
from __future__ import annotations

from .bochner_encoding import BochnerTimeEncoding
from .conv1d_depthwise import DepthwiseCausalConv1d
from .detection_head import DetectionHead
from .gatv2_temporal import TemporalGATv2Layer
from .lipschitz_norm import LipschitzNorm
from .ssmgat import SSMGAT, SSMGATConfig, RMSNorm
from .selective_ssm import SelectiveSSMBlock

__all__ = [
    "SSMGAT",
    "SSMGATConfig",
    "RMSNorm",
    "SelectiveSSMBlock",
    "TemporalGATv2Layer",
    "BochnerTimeEncoding",
    "LipschitzNorm",
    "DetectionHead",
    "DepthwiseCausalConv1d",
]
